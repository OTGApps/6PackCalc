//
//  SPEViewController.h
//  SPE
//
//  Created by Mark Rickert on 1/6/11.
//  Copyright 2011 Mark Rickert. All rights reserved.
//

#import "FlipsideViewController.h"

@interface SPEViewController : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate, FlipsideViewControllerDelegate, UITextFieldDelegate>
{
	IBOutlet UIPickerView *pickerView;
	IBOutlet UITextField *priceField;
	IBOutlet UILabel *calculatedPrice;
	IBOutlet UILabel *oneBottle;
	IBOutlet UISegmentedControl *typeSelector;

	NSMutableArray *arrayAmounts;
	NSMutableArray *arrayOunces;
	NSMutableArray *bottles;;
	NSMutableArray *bottlesAmts;
	NSMutableArray *glasses;
	NSMutableArray *glassesAmts;
	NSMutableArray *kegs;
	NSMutableArray *kegsAmts;
	
	int currentType;
}

- (void) calculateBeerPrice;
- (IBAction)editingEnded:(id)sender;
- (IBAction)showInfo:(id)sender;
- (IBAction)touchedTextField:(id)sender;
- (void) pickOne:(id)sender;
- (NSNumberFormatter *)montoFormatter;
@end

