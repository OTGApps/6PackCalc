//
//  SPEAppDelegate.h
//  SPE
//
//  Created by Mark Rickert on 1/6/11.
//  Copyright 2011 Mark Rickert. All rights reserved.
//

@class SPEViewController;

@interface SPEAppDelegate : NSObject <UIApplicationDelegate>
{
    UIWindow *window;
    SPEViewController *viewController;
}

@property (nonatomic) IBOutlet UIWindow *window;
@property (nonatomic) IBOutlet SPEViewController *viewController;

void uncaughtExceptionHandler(NSException *exception);

@end

