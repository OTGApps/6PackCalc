//
//  SPEViewController.m
//  SPE
//
//  Created by Mark Rickert on 1/6/11.
//  Copyright 2011 Mark Rickert. All rights reserved.
//

#import "SPEViewController.h"

@implementation SPEViewController

-(IBAction)editingEnded:(id)sender
{
	[self calculateBeerPrice];
	[sender resignFirstResponder]; 
}

- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller
{
	[self dismissModalViewControllerAnimated:YES];
}

- (IBAction)showInfo:(id)sender
{
	FlipsideViewController *controller = [[FlipsideViewController alloc] initWithNibName:@"FlipsideView" bundle:nil];
	controller.delegate = self;
	
	controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	[self presentModalViewController:controller animated:YES];
	
}

-(void)textDidChanged:(NSNotification *)notification
{
	[[NSNotificationCenter defaultCenter] removeObserver:self  name:UITextFieldTextDidChangeNotification object:nil];
	UITextField * textField= [notification object];
	NSString * sinPesos= [textField.text stringByReplacingOccurrencesOfString:@"$" withString:@""];
	NSString * sinPuntos= [sinPesos stringByReplacingOccurrencesOfString:@"." withString:@""];
	
	float monto = [sinPuntos floatValue]; 
	
	monto= monto/100;
	
	NSString * cardText= [[self montoFormatter] stringFromNumber:[NSNumber numberWithDouble:monto]]; 
	
	textField.text = ([cardText isEqualToString: @"0"] ? @"":cardText);
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChanged:) name:UITextFieldTextDidChangeNotification object:nil];

	[self calculateBeerPrice];
} 

-(NSNumberFormatter *)montoFormatter
{
	NSNumberFormatter* numberFormatter = [[NSNumberFormatter alloc] init];
	[numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
	[numberFormatter setMaximumFractionDigits:2];
	return numberFormatter;
}


#pragma mark -
#pragma mark Notification Observers

- (void)addObservers {
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textFieldDidChange:) name:@"UITextFieldTextDidChangeNotification" object:nil];    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChanged:) name:@"UITextFieldTextDidChangeNotification" object:nil];    


	if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2)
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidShow:) name:UIKeyboardDidShowNotification object:nil];		
  else
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
}
- (void)removeObservers
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"UITextFieldTextDidChangeNotification" object:nil];
}

- (void) pickOne:(id)sender
{
	UISegmentedControl *segmentedControl = (UISegmentedControl *)sender;
		
	currentType = [segmentedControl selectedSegmentIndex];

	[pickerView reloadComponent:0];
	[self calculateBeerPrice];
}

- (void)viewDidLoad
{

	[self addObservers];
	currentType = 0;	
	
	[typeSelector addTarget:self action:@selector(pickOne:) forControlEvents:UIControlEventValueChanged];
	
	priceField.keyboardType = UIKeyboardTypeNumberPad;	
  priceField.returnKeyType = UIReturnKeyDone;
	
	/* Set up the arrays for the picker */
	
	bottles = [[NSMutableArray alloc] init];
	bottlesAmts = [[NSMutableArray alloc] init];

	glasses = [[NSMutableArray alloc] init];
	glassesAmts = [[NSMutableArray alloc] init];

	kegs = [[NSMutableArray alloc] init];
	kegsAmts = [[NSMutableArray alloc] init];
	
	arrayAmounts = [[NSMutableArray alloc] initWithCapacity:3];
	arrayOunces = [[NSMutableArray alloc] initWithCapacity:3];
	
	[bottles addObject:@"7 oz"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:7.0f]];
	
	[bottles addObject:@"11.2 oz"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:11.2f]];
	
	[bottles addObject:@"33 cl"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:10.8204873f]];
	
	[bottles addObject:@"12 oz"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:12.0f]];

	[bottles addObject:@"0.5 l (16.9 oz)"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:16.9070114f]];
	
	[bottles addObject:@"22 oz (bomber/rocket)"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:22.0f]];

	[bottles addObject:@"750 ml"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:25.360517f]];
	
	[bottles addObject:@"32 oz (bomber)"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:32.0f]];
	
	[bottles addObject:@"40 oz"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:40.0f]];
	
	[bottles addObject:@"64 oz growler"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:64.0f]];
	
	[bottles addObject:@"1 gal growler"];
	[bottlesAmts addObject: [NSNumber numberWithFloat:128.0f]];
	
	[arrayAmounts addObject:bottles];
	[arrayOunces addObject:bottlesAmts];
	
	[glasses addObject:@"Cheater pint (actual: 13 oz)"];
	[glassesAmts addObject: [NSNumber numberWithFloat:13.0f]];
	
	[glasses addObject:@"16 oz (actual: 15 oz)"];
	[glassesAmts addObject: [NSNumber numberWithFloat:15.0f]];
	
	[glasses addObject:@"16 oz fill line"];
	[glassesAmts addObject: [NSNumber numberWithFloat:16.0f]];
	
	[glasses addObject:@"20 oz (actual: 19 oz)"];
	[glassesAmts addObject: [NSNumber numberWithFloat:19.0f]];
	
	[glasses addObject:@"20 oz fill line"];
	[glassesAmts addObject: [NSNumber numberWithFloat:20.0f]];
	
	[glasses addObject:@"0.4 l fill line"];
	[glassesAmts addObject: [NSNumber numberWithFloat:13.5256091f]];
	
	[glasses addObject:@"0.5 l fill line"];
	[glassesAmts addObject: [NSNumber numberWithFloat:16.9070114f]];
	
	[arrayAmounts addObject:glasses];
	[arrayOunces addObject:glassesAmts];
				
	[kegs addObject:@"5 l mini-keg"];
	[kegsAmts addObject: [NSNumber numberWithFloat:169.070114f]];

	[kegs addObject:@"Soda (3 gal)"];
	[kegsAmts addObject: [NSNumber numberWithFloat:384.0f]];
	
	[kegs addObject:@"Cornelius (5 gal)"];
	[kegsAmts addObject: [NSNumber numberWithFloat:640.0f]];
	
	[kegs addObject:@"1/6 barrel (5.16 gal)"];
	[kegsAmts addObject: [NSNumber numberWithFloat:660.48f]];
	
	[kegs addObject:@"Pony (1/4 barrel / 7.75 gal)"];
	[kegsAmts addObject: [NSNumber numberWithFloat:992.0f]];
	
	[kegs addObject:@"Full (1/2 barrel / 15.5 gal)"];
	[kegsAmts addObject: [NSNumber numberWithFloat:1984.0f]];
	
	[arrayAmounts addObject:kegs];
	[arrayOunces addObject:kegsAmts];

	[super viewDidLoad];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}



- (IBAction)touchedTextField:(id)sender
{
	NSLog(@"Toughed the text field");
	priceField.text = @"$0.00";
}


#pragma mark -
#pragma mark Picker View Methods

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)thePickerView
{
	return 1;
}

- (NSInteger)pickerView:(UIPickerView *)thePickerView numberOfRowsInComponent:(NSInteger)component
{
	return [[arrayAmounts objectAtIndex:currentType] count];
}

- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [[arrayAmounts objectAtIndex:currentType] objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)thePickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	[self calculateBeerPrice];
}

- (void)addButtonToKeyboard
{
	// create custom button
	UIButton *doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
	doneButton.frame = CGRectMake(0, 163, 106, 53);
	doneButton.adjustsImageWhenHighlighted = NO;
	if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.0)
  {
		[doneButton setImage:[UIImage imageNamed:@"DoneUp3.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"DoneDown3.png"] forState:UIControlStateHighlighted];
	}
  else
  {        
		[doneButton setImage:[UIImage imageNamed:@"DoneUp.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"DoneDown.png"] forState:UIControlStateHighlighted];
	}
	[doneButton addTarget:self action:@selector(doneButton:) forControlEvents:UIControlEventTouchUpInside];
	// locate keyboard view
	UIWindow* tempWindow = [[[UIApplication sharedApplication] windows] objectAtIndex:1];
	UIView* keyboard;
	for(int i=0; i<[tempWindow.subviews count]; i++)
  {
		keyboard = [tempWindow.subviews objectAtIndex:i];
		// keyboard found, add the button
		if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2)
    {
			if([[keyboard description] hasPrefix:@"<UIPeripheralHost"] == YES)
				[keyboard addSubview:doneButton];
		}
    else
    {
			if([[keyboard description] hasPrefix:@"<UIKeyboard"] == YES)
				[keyboard addSubview:doneButton];
		}
	}
}

- (void)keyboardWillShow:(NSNotification *)note
{
	// if clause is just an additional precaution, you could also dismiss it
	if ([[[UIDevice currentDevice] systemVersion] floatValue] < 3.2)
  {
		[self addButtonToKeyboard];
	}
}

- (void)keyboardDidShow:(NSNotification *)note
{
	// if clause is just an additional precaution, you could also dismiss it
	if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2)
  {
		[self addButtonToKeyboard];
  }
}


- (void)doneButton:(id)sender
{
  [priceField resignFirstResponder];
	[sender resignFirstResponder]; 
}


#pragma mark -
#pragma mark Price View Methods

- (void) calculateBeerPrice
{

	NSInteger nRow = [pickerView selectedRowInComponent:0];
	float myOunces = [[[arrayOunces objectAtIndex:currentType] objectAtIndex:nRow] floatValue];
	float sixPackOunces = 72.0f;
	
	//Convert the selected index over to OZs
	if(myOunces > 0)
  {
		float thisTextFloatValue = [[priceField.text stringByReplacingOccurrencesOfString:@"$" withString:@""] floatValue];
		
		calculatedPrice.text = [NSString stringWithFormat:@"$%.2f", sixPackOunces / myOunces * thisTextFloatValue];
		oneBottle.text = [NSString stringWithFormat:@"One Bottle: $%.2f", sixPackOunces / myOunces * thisTextFloatValue / 6 ];
	}
}

@end