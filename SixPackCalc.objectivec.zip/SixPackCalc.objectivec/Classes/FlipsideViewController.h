//
//  FlipsideViewController.h
//  Six-PackCalc
//
//  Created by Mark Rickert on 1/6/11.
//  Copyright 2011 Mark Rickert. All rights reserved.
//

@protocol FlipsideViewControllerDelegate;

@interface FlipsideViewController : UIViewController
{
	id <FlipsideViewControllerDelegate> __unsafe_unretained delegate;
	IBOutlet UIWebView *credits;
}

@property (nonatomic, unsafe_unretained) id <FlipsideViewControllerDelegate> delegate;
- (IBAction)done:(id)sender;
@end


@protocol FlipsideViewControllerDelegate
- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller;
@end

