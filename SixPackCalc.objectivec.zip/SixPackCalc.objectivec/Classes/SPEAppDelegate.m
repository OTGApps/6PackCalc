//
//  SPEAppDelegate.m
//  SPE
//
//  Created by Mark Rickert on 1/6/11.
//  Copyright 2011 Mark Rickert. All rights reserved.
//

#import "SPEAppDelegate.h"
#import "SPEViewController.h"

@implementation SPEAppDelegate

@synthesize window;
@synthesize viewController;

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
  //Init Flurry tracking
	NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);    
  
	//This is the free Version
	[FlurryAnalytics startSession:@"3V3948P3TTBP2HGPRLCU"];
  
  // Add the view controller's view to the window and display.
  [self.window addSubview:viewController.view];
  [self.window makeKeyAndVisible];
  
  return YES;
}

void uncaughtExceptionHandler(NSException *exception)
{
    [FlurryAnalytics logError:@"Uncaught" message:@"Crash!" exception:exception];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)orientation
{
  return (orientation != UIDeviceOrientationLandscapeLeft) && (orientation != UIDeviceOrientationLandscapeRight);
}

#pragma mark -
#pragma mark Memory management


@end
