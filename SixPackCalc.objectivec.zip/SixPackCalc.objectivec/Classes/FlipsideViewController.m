//
//  FlipsideViewController.m
//  Six-PackCalc
//
//  Created by Mark Rickert on 1/6/11.
//  Copyright 2011 Mark Rickert. All rights reserved.
//

#import "FlipsideViewController.h"
#import "UIWebView+RemoveShadow.h"

@implementation FlipsideViewController

@synthesize delegate;

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
	if (navigationType == UIWebViewNavigationTypeLinkClicked)
  {
		[[UIApplication sharedApplication] openURL:[request URL]];
		return NO;
	}
	
	return YES;
}

- (void)viewDidLoad
{
  [super viewDidLoad];

	[FlurryAnalytics logEvent:@"FLIPSIDE_VIEW"];
    
	self.view.backgroundColor = [UIColor viewFlipsideBackgroundColor];
}

-(void) viewWillAppear:(BOOL)animated
{
  [super viewWillAppear:animated];
  
  NSString *filePath = [[NSBundle mainBundle] pathForResource:@"About" ofType:@"html"];  
  NSString *path = [[NSBundle mainBundle] bundlePath];
  NSString *pathHTML = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
	NSString *html = [NSString stringWithFormat:pathHTML, [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"]];
	
	[credits makeTransparentAndRemoveShadow];
  
	NSURL *baseURL = [NSURL fileURLWithPath:path];
	[credits loadHTMLString:html baseURL:baseURL];
}


- (IBAction)done:(id)sender
{
	[FlurryAnalytics logEvent:@"FLIPSIDE_CLOSE"];

	[self.delegate flipsideViewControllerDidFinish:self];	
}



@end